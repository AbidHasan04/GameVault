<?php 
session_start();
 @include 'DatabaseConnect.php';

?>
<!DOCTYPE html>
<html>

<head><title>Order This game?</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />

<style>
body{ 
    background-color: black;
    font: Arial;
    font-size: 18px;
    border-color: rgb(147, 208, 243);
    color: #69b8ec;
    margin-top: 1px;
    margin-left: 1px;
    
    
} .MainThing{ 
    border-radius: 10px;
    padding: 1px;
    height: 100%;
    width: 100%;
    margin-top: 0px;
} .Content{
    margin-top: 25px;
}
 p{
    font: Arial;
    font-size: 18px;
   } a{
    text-decoration: none;
    color: rgb(114, 173, 212);
    
   }
   
   a:hover{
    transition: 0.3s; 
             color: aliceblue;
             
   } img:hover{
transition: 0.3s;
opacity: 0.7;
   } .RelatedGameDetails:hover, .SideGames:hover{
    opacity: 0.8;
    transition:0.3s;
   }

   .material-symbols-outlined{
    font-size: 60px;
    color: aliceblue;
    
   }

.Menu{
    color: rgb(128, 183, 219);
    text-decoration: none;
    height: 115px;
    width: 100%;
    display: block;
    

}  .MenuBar{
    display: block;
    height:30px;
    border-radius: 10px;
    border-color:rgb(147, 208, 243);
    border-width: 1px;
    border-style: solid;
    padding-left: 10px;
    padding-right: 10px;
    padding-top:7px;
    padding-bottom:7px;
    margin-left: 5px;

} .Home{
    display: inline-block;
    color: rgb(119, 180, 221);
    margin-right: 25px;
    margin-left: 5px;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 5px;
    padding-bottom: 4px;
} .Title{
    margin-top: 25px;
    margin-bottom: 10px;
    margin-left: 5px;
    padding-left: 10px;
    padding-top: 20px;
    display: block;
    font-size: 50px;
    font-weight: bold;
    border-radius: 20px;
    border-width: 1px;
    border-color:rgb(122, 175, 211);
    border-width: 1px;
    border-style: solid;
    
} .SignUp:hover{
    font-size: 19px;
    transition:0.3s;
}

.SideBar{
    display: inline-block;
    width: 270px;
    height:fit-content;
    vertical-align: top;
    border-radius: 10px;
    border-width: 1px;
    border-style: solid;
    margin-top: 0px;
    
    
} .SideBarName{
     color:rgb(147, 208, 243);
     font-size: 25px;
     width: 258px;
    border-radius: 5px;
    border-width: 1px;
    border-style: solid;
    display: block;
    padding-right: 3px;
    padding-left: 3px;
    padding-top: 20px;
    padding-bottom:5px;
    margin-top: 2px;
    margin-bottom: 4px;
    margin-left: 2px;
    
} .SideGameImg{
    display: block;
    width: 260px;
    height: 300px;
    border-radius: 10px;
    border-width: 1px;
    border-style: solid;
    padding-top: 10px;
} .SideGameName{ font-size: 30x;
    display: block;
    color: aliceblue;
    border-radius: 5px;
    border-width: 1px;
    border-style:none;
    margin-left: 2px;
    margin-right: 3px;
    margin-top: 3px;
    margin-bottom: 3px;
    padding-left: 6px;
    
} .SideGames{
    display: block;
    margin-left: 3px;
    margin-top: 3px;
    height: 355px;
    
} .SideGameName:hover{
    transition: 0.3s; 
    text-decoration:underline;
    font-weight: 700;
}


.Horizontal{
    width:1050px;
    height: 2941px;
    display: inline-block;
    border-width: 1px;
    border-radius: 20px;
    border-color: rgb(147, 208, 243);
    border-style: solid;
    margin-left: 5px;
    margin-right: 5px;
}

.ClickedGameDetails{
    width:1040px;
    display:block;
    border-width: 1px;
    border-radius: 20px;
    border-color: rgb(147, 208, 243);
    border-style: solid;
    margin-left: 3px;
    margin-right: 5px;
    margin-top: 5px;
    margin-bottom: 5px;
    height: 865px;

} .ColorText{
    margin-left: 3px;
    color:rgb(226, 241, 255);
    font-weight:700;
    font-size: 20px;
} .Text{
    Margin-left: 20px;
} .TextLink{
color: aliceblue;
} .TextLink:hover{
    font-size: 18px;
    font-weight: 600;
}

.DetailImage{
    width:320px;
    height: 450px;
    display: inline-block;
    margin-top:30px;
    margin-bottom: 10px;
    margin-left: 10px;
    border-radius: 10px;
    border-style: solid
    ;
} .DetailText{
    color:#69b8ec;
    display: inline-block;
    margin-top: 10px;
    margin-bottom:10px;
    
    border-radius: 10px;
    border-width: 1px;
    font-size:25px;
    margin-left: 30px;
    margin-top: 30px;
    vertical-align: top;

} .DetailName{font-size: 40px;
    margin-top: 5px;
    margin-bottom:30px;
    margin-left:10px;
    

} .DetailRandom1{
    margin-top: 5px;
    margin-bottom:20px;
    margin-left:10px;
    font-size:22px;

} .DetailRandom2{
    margin-top: 10px;
    margin-bottom:10px;
    margin-left:10px;
    font-size:22px;

}
 .DetailPrice{color: rgb(144, 255, 129);
    font-size: 32px;
    font-weight: 500;
    margin-top: 10px;
    margin-bottom:5px;
    margin-left:3px;
} .DetailDiscounts{
    color: rgb(255, 123, 123);
    font-size:30px;
    margin-left: 3px;
    margin-top: 10px;
} .BuyButton{
    margin-left:10px;
    font-size: 25px;
    border-style: solid;
    border-color: #69b8ec;
    border-width:1px;
    border-radius: 8px;
    background-color:#000000;
    color: aliceblue;
    padding-top: 4px;
    padding-bottom: 4px;
    padding-left: 12px;
    padding-right: 12px;
    text-align: center;
} .BuyButton:hover{
    border-color: #69b8ec;
    border-width:2px;
    transition: 0.1s;
    border-radius: 4px;
    padding-right: 15px;
    padding-left:15px;

} .ConsoleLink:hover{
    font-size: 25px;
    font-weight: 700; 
    transition: 0.1s;
}
.NormalText{
    color:#69b8ec;
    margin-left: 10px;
    font-size: 22px;
}


.RelatedGames{ 
    display: block;
    border-style: solid;
    border-width: 1px;
    border-radius: 20px;
    margin-left:5px;
    margin-right:5px;
    width: 1030px;
    height:358px;

} .RelatedGameDetails{
    display:inline-block;
    margin: 7px;
    margin-left: 5px;
    margin-right: 5px;
    border-style: solid;
    border-radius: 20px;
    border-width: 1px;
} .RelatedGameTitle{
    font-size: 30px;
    margin-bottom:5px;
    margin-top:12px;
    margin-left: 5px;
} 
.RelatedImg{
    border-radius:20px;
    width:150px;
    height: 210px;
    display: block;
}.RelatedName{
    font-size: 15px;
    margin: 2px;

} .RelatedPrice{
    color: rgb(109, 214, 95);
    font-size:15px;
}


.Faves{
    width: 1040px;
    height: 1400px;
    display: block;
    border-style: solid;
    border: none;
    padding-top: 10px;
} .GameDetails{
    width: 315px;
    height:500px;
    display: inline-block;
    border-style: solid;
    border-width: 1px;
    border-radius: 20px;
    border-color: rgb(147, 208, 243);
    border-style: solid;
    margin-left: 11px;
    margin-right: 3px;
    margin-top: 3px;
} .FaveCover{
    display: block;
    width:314px;
    height: 400px;
    border-radius: 20px;
    margin-bottom: 5px;

} .FaveTitle{
    color:rgb(118, 183, 221);
     font-size: 30px;
     font-weight: 600;
     width: 340px;
    border-radius: 5px;
    border-width: 1px;
    
    display: block;
    padding-right: 650px;
    padding-left: 5px;
    margin-top: 7px;
    margin-bottom: 5px;
    margin-right: 3px;
    margin-left: 14px;
} .FaveGameName{
font-size: 20px;
font-weight: 600;
color: aliceblue;
margin-left:10px;
} .FaveGameName:hover{
    transition: 0.3s; 
    text-decoration:underline;
} .FaveGamePrice{
    color: rgb(109, 214, 95);
    font-size: 25px;
    margin-left: 10px;
    margin-top:5px;
}


</style>

</head>



<body><div class="MainThing">


<div class="Menu">
    <a class="Title" href="GVFrontPage.html">GAMEVAULT</a>
    <div class="MenuBar">
<a class="Home" href="GVFrontPage.html">Home</a>
<a class="Home" href="#">Games</a>
<a class="Home" href="#">Hardware</a> 
<a class="Home" style="font-weight:600;" href="GVLogInPage.html">Log In</a>
<a class="SignUp" style="font-weight:600; color:aliceblue" href="GVSignUpPage.html">Sign Up</a>
</div>
</div>

<div class="Content">
<div class = Horizontal>

    
    <div class="RelatedGames">
        <p class="RelatedGameTitle">Related Games</p>

    <div href="#" class="RelatedGameDetails">
        <img src="https://th.bing.com/th/id/R.1a7afb144b72c10b6a5fe9e10599d40e?rik=ls48KFag31qf%2bA&riu=http%3a%2f%2fwww.mobygames.com%2fimages%2fcovers%2fl%2f121415-metal-gear-solid-the-essential-collection-playstation-other.png&ehk=wJ3MMrHiEO6mELz%2fEuC%2f4WTUXpQ%2fSTqmKSiYblNolB8%3d&risl=&pid=ImgRaw&r=0" class="RelatedImg">
        <a href="#" class="RelatedName">Metal Gear Solid 2</a>
        <p class="RelatedPrice">$8.00</p>   
    </div>
    <div href="#" class="RelatedGameDetails">
        <img src="https://th.bing.com/th/id/R.000ce909e42dc91435970ee61d975c9f?rik=QmhBloKHNcQkHw&riu=http%3a%2f%2fwww.mobygames.com%2fimages%2fcovers%2fl%2f5929-silent-hill-playstation-front-cover.jpg&ehk=9Is1WQbbUoR0mCuc0etGIErrlsufGeObrQ%2ftXZ1a9qY%3d&risl=&pid=ImgRaw&r=0" class="RelatedImg">
        <a href="#" class="RelatedName">Silent Hill</a>
        <p class="RelatedPrice">$6.99</p>
    </div>
    <div href="#" class="RelatedGameDetails">
        <img src="https://th.bing.com/th/id/R.bead63af99d9d9774982fa0efe594d2f?rik=UeXPs%2bviPYCpQw&riu=http%3a%2f%2f3.bp.blogspot.com%2f-hA9ox0qkdhs%2fU7PbMLvunAI%2fAAAAAAAAFfE%2fe52afXrrPtE%2fs1600%2fCrash%2bBandicoot%2bcover1.jpg&ehk=b21E%2bMGr7p6Sb0%2bzcsOxzSgfWqUOPgddjL2C9G5QVH8%3d&risl=&pid=ImgRaw&r=0" class="RelatedImg">
        <a href="#" class="RelatedName">Crash Bandicoot</a>
        <p class="RelatedPrice">$9.00</p>
        
    </div>
    <div href="#" class="RelatedGameDetails">
        <img src="https://www.mobygames.com/images/covers/l/21573-tom-clancy-s-splinter-cell-playstation-2-front-cover.jpg" class="RelatedImg">
        <a href="#" class="RelatedName">Tom Clancy's Splinter Cell</a>
        <p class="RelatedPrice">$10.00</p>
        
    </div>
    <div href="#" class="RelatedGameDetails">
        <img src="https://th.bing.com/th/id/OIP.bMYfelLYPMg4chdlsZlFzgHaJa?pid=ImgDet&rs=1" class="RelatedImg">
        <a href="#" class="RelatedName">Resident Evil</a>
        <p class="RelatedPrice">$7.00</p>
        
    </div>
    <div href="#" class="RelatedGameDetails">
        <img src="https://cdromance.com/wp-content/uploads/2016/07/pokemon-ranger-shadows-of-almia-usa-coverart.jpg" class="RelatedImg">
        <a href="#" class="RelatedName">Pokemon Rangers</a>
        <p class="RelatedPrice">$6.00</p>
        
    </div>

    </div>
    
</div>






</div>



<?php 
include_once('sidegames.php');
?>



</div>


</div></body>





</html>
